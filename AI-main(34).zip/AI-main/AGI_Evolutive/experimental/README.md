# Experimental utilities

Legacy maintenance scripts and exploratory patches are stored here to keep the
main package namespace clean.  They are retained for reference and can be
rehydrated manually if needed, but they are not part of the supported runtime
code path.
