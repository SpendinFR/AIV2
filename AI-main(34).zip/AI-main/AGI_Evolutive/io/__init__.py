"""Interfaces for perception and action subsystems."""
